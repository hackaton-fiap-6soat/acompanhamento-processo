from dotenv import load_dotenv

from adapter.adaptersDB import AcompanhamentoDB

load_dotenv(dotenv_path='.env')

dynamodb = AcompanhamentoDB("AcompanhamentoProcesso")

print(dynamodb.buscar_processos("12345"))