class DynamoDBException:
    pass