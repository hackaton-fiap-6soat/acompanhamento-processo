import os
import zipfile


def zip_code(source_dir, output_filename, include_dirs=None):
    # Defina o diretório do ambiente virtual como '.venv'
    venv_dir = './.venv'

    # Definir os diretórios a serem incluídos (se não for informado, inclui todos)
    if include_dirs is None:
        include_dirs = []

    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Adicionar código-fonte na pasta python/
        python_code_dir = "python/"
        for root, dirs, files in os.walk(source_dir):
            # Ignorar '__pycache__' e o diretório do ambiente virtual
            dirs[:] = [d for d in dirs if d != '__pycache__' and d != os.path.basename(venv_dir)]

            # Incluir arquivos da raiz ou de diretórios específicos
            if root == source_dir or os.path.basename(root) in include_dirs:
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, source_dir)
                    # Verifique se é o arquivo main.py e coloque diretamente na pasta python
                    if file == 'main.py':
                        zipf.write(file_path, os.path.join(python_code_dir, 'main.py'))
                    else:
                        zipf.write(file_path, os.path.join(python_code_dir,
                                                           arcname))  # Outros arquivos do código-fonte vão para 'python/'

        # Adicionar as bibliotecas do ambiente virtual dentro da pasta python/lib/
        site_packages_dir = os.path.join(venv_dir, "Lib", "site-packages")
        for root, dirs, files in os.walk(site_packages_dir):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, site_packages_dir)
                # Adiciona as bibliotecas diretamente dentro de 'python/lib/'
                zipf.write(file_path,
                           os.path.join(python_code_dir, "lib", arcname))  # Bibliotecas dentro de 'python/lib/'


# Diretórios e arquivo ZIP de saída
source_directory = '.'  # Diretório com o código-fonte
output_file = './terraform/lambda/package.zip'

# Definindo as pastas a serem incluídas
include_dirs = ['adapter', 'data', 'domain', 'port']

# Criar o ZIP
zip_code(source_directory, output_file, include_dirs)
print(f"Pacote criado: {output_file}")
