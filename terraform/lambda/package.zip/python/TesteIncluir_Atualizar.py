from adapter.adaptersDB import AcompanhamentoDB
from domain.services import AcompanhamentoService

dynamodb = AcompanhamentoDB("AcompanhamentoProcesso")

processoUsuario = {
	"id_usuario": "U12345",
	"processo": "geracao",
	"nome_arquivo": "Arquivo1",
	"status": "ok"
}

service = AcompanhamentoService(dynamodb)

service.criar_atualizar_processo(processoUsuario)