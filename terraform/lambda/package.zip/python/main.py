import json
import logging

from fastapi import FastAPI
from mangum import Mangum
from adapter.adaptersDB import AcompanhamentoDB
from adapter.http_api import HTTPAPIAdapter
from domain.services import AcompanhamentoService

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def create_app() -> FastAPI:
    async def lifespan(app: FastAPI):
        logger.debug("Iniciando ciclo de vida do aplicativo")

        try:
            dynamodb = AcompanhamentoDB("AcompanhamentoProcesso")
            service = AcompanhamentoService(dynamodb)
            http_api_adapter = HTTPAPIAdapter(service)

            logger.debug("Adicionando roteadores")
            app.include_router(http_api_adapter.router)

        except Exception as e:
            logger.error("Erro durante a inicialização do ciclo de vida: %s", e)
            raise

        yield
        logger.debug("Finalizando ciclo de vida do aplicativo")

    app = FastAPI(lifespan=lifespan)

    @app.get("/")
    async def root():
        return {"message": "Hello World"}

    @app.get("/hello/{name}")
    async def say_hello(name: str):
        return {"message": f"Hello {name}"}

    return app

def sqs_handler(event, context):
    dynamodb = AcompanhamentoDB("AcompanhamentoProcesso")
    service = AcompanhamentoService(dynamodb)
    logger.debug(f"Recebido evento do SQS: {json.dumps(event)}")

    service.criar_atualizar_processo(json.dumps(event))

    return {
        "statusCode": 200,
        "body": json.dumps("Mensagem processada com sucesso")
    }

def data_query_handler(event, context):
    dynamodb = AcompanhamentoDB("AcompanhamentoProcesso")
    service = AcompanhamentoService(dynamodb)

    logger.debug(f"Consulta de dados solicitada: {json.dumps(event)}")

    acompanhamento = service.buscar_acompanhamento("U12346")

    return {
        "statusCode": 200,
        "body": json.dumps(acompanhamento)
    }

app = create_app()

handler = Mangum(app)