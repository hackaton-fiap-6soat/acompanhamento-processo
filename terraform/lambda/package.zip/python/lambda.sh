#!/bin/bash

# Configurações
SOURCE_DIR="."                         # Diretório do código-fonte
VENV_DIR="./.venv"                      # Diretório do ambiente virtual
OUTPUT_FILE="./terraform/lambda/package.zip"     # Caminho para o arquivo zip de saída
INCLUDE_FOLDERS=("adapter" "data" "domain" "port")  # Lista de pastas específicas a incluir no pacote

# Limpar zip anterior, se existir
if [ -f "$OUTPUT_FILE" ]; then
    echo "Removendo pacote zip anterior..."
    rm "$OUTPUT_FILE"
fi

# Criar diretório temporário para o empacotamento
TEMP_DIR="./temp_package"
mkdir -p "$TEMP_DIR"

echo "Copiando arquivos da raiz..."
find "$SOURCE_DIR" -maxdepth 1 -type f \( -name "*.py" -o -name "*.json" -o -name "*.yaml" -o -name "*.yml" \) \
    -exec cp --parents {} "$TEMP_DIR" \;

echo "Incluindo pastas específicas..."
for folder in "${INCLUDE_FOLDERS[@]}"; do
    if [ -d "$SOURCE_DIR/$folder" ]; then
        cp -r "$SOURCE_DIR/$folder" "$TEMP_DIR/"
    else
        echo "Pasta '$folder' não encontrada. Ignorando..."
    fi
done

echo "Copiando bibliotecas do ambiente virtual..."
if [ -d "$VENV_DIR" ]; then
    SITE_PACKAGES=$(find "$VENV_DIR" -type d -name "site-packages" | head -n 1)
    if [ -n "$SITE_PACKAGES" ]; then
        cp -r "$SITE_PACKAGES/." "$TEMP_DIR/"
    else
        echo "Diretório site-packages não encontrado no ambiente virtual!"
        exit 1
    fi
else
    echo "Ambiente virtual inválido ou não encontrado!"
    exit 1
fi

echo "Compactando arquivos..."
cd "$TEMP_DIR" || exit
zip -r "$OUTPUT_FILE" . >/dev/null
cd - || exit

echo "Limpando arquivos temporários..."
rm -rf "$TEMP_DIR"

echo "Pacote criado com sucesso: $OUTPUT_FILE"
